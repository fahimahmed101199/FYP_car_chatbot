from langchain.llms import OpenAI
import streamlit as st
from PIL import Image
from dotenv import load_dotenv
from langchain_community.document_loaders import TextLoader
from langchain_community.vectorstores import FAISS
from langchain_openai import OpenAIEmbeddings
from langchain_text_splitters import CharacterTextSplitter
from langchain.retrievers import ContextualCompressionRetriever
from langchain.retrievers.document_compressors import LLMChainFilter
from langchain_openai import OpenAI
import warnings
warnings.filterwarnings("ignore")
import os

from langchain.llms import OpenAI
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain
import time 


os.environ["OPENAI_API_KEY"] = "sk-proj-rUgMuAb1pOkB8cHrW90DT3BlbkFJoyHyv14vFx0F2lozflAw"
# Load openAI model and get response

  
documents = TextLoader("data/car.txt").load()
text_splitter = CharacterTextSplitter(chunk_size=1000, chunk_overlap=0)
texts = text_splitter.split_documents(documents)
retriever = FAISS.from_documents(texts, OpenAIEmbeddings()).as_retriever()
llm = OpenAI(temperature=0.5)
_filter = LLMChainFilter.from_llm(llm)
compression_retriever = ContextualCompressionRetriever(
    base_compressor=_filter, base_retriever=retriever
)

def get_openai_response(question):
    responce = compression_retriever.get_relevant_documents(question) + compression_retriever.get_relevant_documents("car")
        
    template = """You are company is called Fahim Auto's.Use the given list of cars {context} to extractonly from the data provided based the following input: {question}. Make sure to answer keep the aswers with 60 words. Make the format for each car as follows a small summery(15 words) and then bullet points of some features and line break. Also always include price and mileage. Only respond to car buying questions """
    
    llm = OpenAI(temperature=0.5)
    prompt = PromptTemplate(
    input_variables=["context", "question"],
    template=template,)
    chain = LLMChain(llm=llm, prompt=prompt)
    return chain.run({
    'context': responce,
    'question':question
}) 





# Initialize stramlit app
st.set_page_config(page_title="Fahim's Autos")
img = Image.open('img/auto_logo.png')
st.image(img, use_column_width=True)
# Get input text
input = st.text_input("What are car are you looking for ?: ", key=input)
response = get_openai_response(input)

# Submit button

submit = st.button("Generate a response")

if submit:
    st.subheader("Answer: ")
    st.write(response)

    

    
    
    



